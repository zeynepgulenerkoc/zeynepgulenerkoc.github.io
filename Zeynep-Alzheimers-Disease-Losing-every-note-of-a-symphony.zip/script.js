/* .js files add interaction to your website */

var submitBtn = document.getElementById("storyBtn");
var post = document.getElementById("storyPosting");


//condition if the submit button clicked
if (submitBtn) {
  submitBtn.addEventListener("click", displayStory);
}

function displayStory() {
  var fName = document.getElementById("fname").value;
  var lName = document.getElementById("lname").value;
  var storyBox = document.getElementById("story").value;
  var text = fName + " " + lName + "<br>" + storyBox;
  post.innerHTML = text;
  //return document.getElementById('storyPosting').innerHTML = text;
}

var firstFact = "Since 1905, when Alzheimer’s Disease is defined, an actual cure doesn’t exist."
  ;
var secondFact = "Caregivers need  mental support and education. ";
var thirdFact = "Early diagnosis can change lifes.";
var fourthFact = "It is assumed that Alzhiemer’s Disease is based on 2 hypothesis amyloid and tau however questions still exist. ";


 

var factList = [firstFact, secondFact, thirdFact, fourthFact];



var myBtn = document.getElementById("myButton");
var fact = document.getElementById ("fact");

var count = 0;

myBtn.addEventListener("click",displayFact);

fact.innerHTML = factList [count];

function displayFact(){
  fact.innerHTML = factList[count];
  count++;
    if (count == factList.length) {
      count = 0;
    }
  
}






























/*
var factList = [
"Since 1905, when Alzheimer’s Disease is defined, an actual cure doesn’t exist.",
  "Early diagnosis can change lifes.",
 "Caregivers need  mental support and education. ",
"It is assumed that Alzhiemer’s Disease is based on 2 hypothesis amyloid and tau however questions still exist. ",
  
];

function displayFact(){
  fact.innerHTML = factList(count);
  count++;
  if (count == factlist.length){
    count = 0;
    
  }

  


var fact = document.getElementById("fact");
var myButton = document.getElementById("myButton");

myButton.addEventListener("click",displayfact)


  
}
*/ 